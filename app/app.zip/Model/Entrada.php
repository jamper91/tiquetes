<?php
App::uses('AppModel', 'Model');
/**
 * Entrada Model
 *
 * @property Paper $Paper
 * @property Input $Input
 */
class Entrada extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	public $belongsTo = array(
		'Stage' => array(
			'className' => 'Stage',
			'foreignKey' => 'stage_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	public $hasAndBelongsToMany = array(
		'Input' => array(
			'className' => 'Input',
			'joinTable' => 'entradas_inputs',
			'foreignKey' => 'entrada_id',
			'associationForeignKey' => 'input_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		),
            'Categoria' => array(
			'className' => 'Categoria',
			'joinTable' => 'categorias_entradas',
			'foreignKey' => 'entrada_id',
			'associationForeignKey' => 'categoria_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		),
            
	);

}
